# Invoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **string** |  | 
**buyer_email** | **string** |  | 
**cancel_url** | **string** |  | 
**expire_time** | **string** |  | 
**succ_url** | **string** |  | 
**invoice_id** | **string** |  | 
**bitpay_invoice_id** | **string** |  | 
**notify_email** | **string** |  | 
**status** | **string** |  | 
**time** | **string** |  | 
**fiat_cents** | **string** |  | 
**satoshis** | **string** |  | 
**info** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Merchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **string** |  | 
**last_name** | **string** |  | 
**coin_balance** | **int** |  | 
**fiat_balance** | **int** |  | 
**merchant_type** | **string** |  | 
**organization** | **string** |  | 
**status** | **string** |  | 
**website** | **string** |  | 
**address** | **string** |  | 
**admin_email** | **string** |  | 
**business_type** | **string** |  | 
**info** | **string** |  | 
**min_coin_settlement** | **int** |  | 
**min_fiat_settlement** | **int** |  | 
**tel** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



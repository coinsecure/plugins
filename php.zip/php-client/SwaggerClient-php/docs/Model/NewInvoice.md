# NewInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_id** | **string** |  | 
**fiat** | **int** |  | 
**succ_url** | **string** |  | 
**cancel_url** | **string** |  | 
**buyer_email** | **string** |  | 
**notify_email** | **string** |  | 
**info** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



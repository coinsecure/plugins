# FailInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **bool** |  | [default to false]
**message** | [**\Swagger\Client\Model\JsValue**](JsValue.md) |  | 
**time** | [**\DateTime**](\DateTime.md) |  | 
**method** | **string** |  | 
**title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



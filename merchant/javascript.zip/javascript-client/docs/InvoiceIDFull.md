# CoinMerchantApiDocumentation.InvoiceIDFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**from** | **Integer** |  | 
**to** | **Integer** |  | 
**max** | **Integer** |  | 
**offset** | **Integer** |  | 



# CoinMerchantApiDocumentation.Merchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** |  | 
**lastName** | **String** |  | 
**coinBalance** | **Integer** |  | 
**fiatBalance** | **Integer** |  | 
**merchantType** | **String** |  | 
**organization** | **String** |  | 
**status** | **String** |  | 
**website** | **String** |  | 
**address** | **String** |  | 
**adminEmail** | **String** |  | 
**businessType** | **String** |  | 
**info** | **String** |  | 
**minCoinSettlement** | **Integer** |  | 
**minFiatSettlement** | **Integer** |  | 
**tel** | **String** |  | 



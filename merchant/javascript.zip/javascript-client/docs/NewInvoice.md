# CoinMerchantApiDocumentation.NewInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderID** | **String** |  | 
**fiat** | **Integer** |  | 
**succURL** | **String** |  | 
**cancelURL** | **String** |  | 
**buyerEmail** | **String** |  | 
**notifyEmail** | **String** |  | 
**info** | **String** |  | 



# CoinMerchantApiDocumentation.JsValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



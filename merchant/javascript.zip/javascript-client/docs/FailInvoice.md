# CoinMerchantApiDocumentation.FailInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | [default to false]
**message** | [**JsValue**](JsValue.md) |  | 
**time** | **Date** |  | 
**method** | **String** |  | 
**title** | **String** |  | [optional] 



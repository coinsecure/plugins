# CoinMerchantApiDocumentation.SuccessInvoices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | [default to false]
**message** | [**[Invoice]**](Invoice.md) |  | 
**time** | **Date** |  | 
**method** | **String** |  | 
**title** | **String** |  | [optional] 



# CoinMerchantApiDocumentation.SuccessMerchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | [default to false]
**message** | [**Merchant**](Merchant.md) |  | 
**time** | **Date** |  | [optional] 
**method** | **String** |  | [optional] 
**title** | **String** |  | [optional] 



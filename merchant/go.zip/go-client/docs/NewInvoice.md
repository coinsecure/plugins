# NewInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderID** | **string** |  | [default to null]
**Fiat** | **int64** |  | [default to null]
**SuccURL** | **string** |  | [default to null]
**CancelURL** | **string** |  | [default to null]
**BuyerEmail** | **string** |  | [default to null]
**NotifyEmail** | **string** |  | [default to null]
**Info** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



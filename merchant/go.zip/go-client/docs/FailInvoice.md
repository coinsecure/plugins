# FailInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Success** | **bool** |  | [default to null]
**Message** | [**JsValue**](JsValue.md) |  | [default to null]
**Time** | [**time.Time**](time.Time.md) |  | [default to null]
**Method** | **string** |  | [default to null]
**Title** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



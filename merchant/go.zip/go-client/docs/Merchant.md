# Merchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstName** | **string** |  | [default to null]
**LastName** | **string** |  | [default to null]
**CoinBalance** | **int64** |  | [default to null]
**FiatBalance** | **int64** |  | [default to null]
**MerchantType** | **string** |  | [default to null]
**Organization** | **string** |  | [default to null]
**Status** | **string** |  | [default to null]
**Website** | **string** |  | [default to null]
**Address** | **string** |  | [default to null]
**AdminEmail** | **string** |  | [default to null]
**BusinessType** | **string** |  | [default to null]
**Info** | **string** |  | [default to null]
**MinCoinSettlement** | **int64** |  | [default to null]
**MinFiatSettlement** | **int64** |  | [default to null]
**Tel** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



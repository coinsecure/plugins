# Invoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** |  | [default to null]
**BuyerEmail** | **string** |  | [default to null]
**CancelURL** | **string** |  | [default to null]
**ExpireTime** | **string** |  | [default to null]
**SuccURL** | **string** |  | [default to null]
**InvoiceID** | **string** |  | [default to null]
**BitpayInvoiceID** | **string** |  | [default to null]
**NotifyEmail** | **string** |  | [default to null]
**Status** | **string** |  | [default to null]
**Time** | **string** |  | [default to null]
**FiatCents** | **string** |  | [default to null]
**Satoshis** | **string** |  | [default to null]
**Info** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



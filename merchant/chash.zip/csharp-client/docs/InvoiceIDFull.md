# IO.Swagger.Model.InvoiceIDFull
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**From** | **long?** |  | 
**To** | **long?** |  | 
**Max** | **int?** |  | 
**Offset** | **long?** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


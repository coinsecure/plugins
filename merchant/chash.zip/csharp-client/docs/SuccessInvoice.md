# IO.Swagger.Model.SuccessInvoice
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Success** | **bool?** |  | [default to false]
**Message** | [**Invoice**](Invoice.md) |  | 
**Time** | **DateTime?** |  | 
**Method** | **string** |  | 
**Title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


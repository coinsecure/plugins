# IO.Swagger.Model.NewInvoice
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderID** | **string** |  | 
**Fiat** | **long?** |  | 
**SuccURL** | **string** |  | 
**CancelURL** | **string** |  | 
**BuyerEmail** | **string** |  | 
**NotifyEmail** | **string** |  | 
**Info** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


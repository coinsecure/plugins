# IO.Swagger.Model.Invoice
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | **string** |  | 
**BuyerEmail** | **string** |  | 
**CancelURL** | **string** |  | 
**ExpireTime** | **string** |  | 
**SuccURL** | **string** |  | 
**InvoiceID** | **string** |  | 
**BitpayInvoiceID** | **string** |  | 
**NotifyEmail** | **string** |  | 
**Status** | **string** |  | 
**Time** | **string** |  | 
**FiatCents** | **string** |  | 
**Satoshis** | **string** |  | 
**Info** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


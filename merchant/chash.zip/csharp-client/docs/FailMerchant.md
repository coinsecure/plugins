# IO.Swagger.Model.FailMerchant
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Success** | **bool?** |  | [default to false]
**Message** | [**JsValue**](JsValue.md) |  | 
**Time** | **DateTime?** |  | [optional] 
**Method** | **string** |  | [optional] 
**Title** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# Merchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**first_name** | **str** |  | 
**last_name** | **str** |  | 
**coin_balance** | **int** |  | 
**fiat_balance** | **int** |  | 
**merchant_type** | **str** |  | 
**organization** | **str** |  | 
**status** | **str** |  | 
**website** | **str** |  | 
**address** | **str** |  | 
**admin_email** | **str** |  | 
**business_type** | **str** |  | 
**info** | **str** |  | 
**min_coin_settlement** | **int** |  | 
**min_fiat_settlement** | **int** |  | 
**tel** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



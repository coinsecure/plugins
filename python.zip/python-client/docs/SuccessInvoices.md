# SuccessInvoices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **bool** |  | [default to False]
**message** | [**list[Invoice]**](Invoice.md) |  | 
**time** | **datetime** |  | 
**method** | **str** |  | 
**title** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



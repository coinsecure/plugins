# NewInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_id** | **str** |  | 
**fiat** | **int** |  | 
**succ_url** | **str** |  | 
**cancel_url** | **str** |  | 
**buyer_email** | **str** |  | 
**notify_email** | **str** |  | 
**info** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



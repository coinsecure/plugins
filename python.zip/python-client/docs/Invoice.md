# Invoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **str** |  | 
**buyer_email** | **str** |  | 
**cancel_url** | **str** |  | 
**expire_time** | **str** |  | 
**succ_url** | **str** |  | 
**invoice_id** | **str** |  | 
**bitpay_invoice_id** | **str** |  | 
**notify_email** | **str** |  | 
**status** | **str** |  | 
**time** | **str** |  | 
**fiat_cents** | **str** |  | 
**satoshis** | **str** |  | 
**info** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



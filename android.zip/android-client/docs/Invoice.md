
# Invoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address** | **String** |  | 
**buyerEmail** | **String** |  | 
**cancelURL** | **String** |  | 
**expireTime** | **String** |  | 
**succURL** | **String** |  | 
**invoiceID** | **String** |  | 
**bitpayInvoiceID** | **String** |  | 
**notifyEmail** | **String** |  | 
**status** | **String** |  | 
**time** | **String** |  | 
**fiatCents** | **String** |  | 
**satoshis** | **String** |  | 
**info** | **String** |  | 




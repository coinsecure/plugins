
# Merchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** |  | 
**lastName** | **String** |  | 
**coinBalance** | **Long** |  | 
**fiatBalance** | **Long** |  | 
**merchantType** | **String** |  | 
**organization** | **String** |  | 
**status** | **String** |  | 
**website** | **String** |  | 
**address** | **String** |  | 
**adminEmail** | **String** |  | 
**businessType** | **String** |  | 
**info** | **String** |  | 
**minCoinSettlement** | **Long** |  | 
**minFiatSettlement** | **Long** |  | 
**tel** | **String** |  | 




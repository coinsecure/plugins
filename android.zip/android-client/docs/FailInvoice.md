
# FailInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | 
**message** | [**JsValue**](JsValue.md) |  | 
**time** | [**Date**](Date.md) |  | 
**method** | **String** |  | 
**title** | **String** |  |  [optional]




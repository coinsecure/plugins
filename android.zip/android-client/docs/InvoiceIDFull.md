
# InvoiceIDFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**from** | **Long** |  | 
**to** | **Long** |  | 
**max** | **Integer** |  | 
**offset** | **Long** |  | 




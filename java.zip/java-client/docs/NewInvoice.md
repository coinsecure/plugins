
# NewInvoice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderID** | **String** |  | 
**fiat** | **Long** |  | 
**succURL** | **String** |  | 
**cancelURL** | **String** |  | 
**buyerEmail** | **String** |  | 
**notifyEmail** | **String** |  | 
**info** | **String** |  | 




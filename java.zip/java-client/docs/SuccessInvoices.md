
# SuccessInvoices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | 
**message** | [**List&lt;Invoice&gt;**](Invoice.md) |  | 
**time** | [**Date**](Date.md) |  | 
**method** | **String** |  | 
**title** | **String** |  |  [optional]




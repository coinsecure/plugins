
# SuccessMerchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **Boolean** |  | 
**message** | [**Merchant**](Merchant.md) |  | 
**time** | [**Date**](Date.md) |  |  [optional]
**method** | **String** |  |  [optional]
**title** | **String** |  |  [optional]



